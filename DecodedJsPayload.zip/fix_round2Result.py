import sys
import re

def deobfuscate(input_file):
    try:
        # Open the input file
        with open(input_file, 'r') as f:
            content = f.read()

        # Use regular expression to find all the concatenated string parts in the file
        # This pattern looks for strings enclosed in single or double quotes and concatenated with '+'
        pattern = re.compile(r"\'(.*?)\'|\”(.*?)\”")  # Matches single or double quoted strings
        fragments = re.findall(pattern, content)

        # Extract all non-empty fragments from the match groups
        # Each fragment will be part of the obfuscated code
        code_fragments = [f for fragment in fragments for f in fragment if f]

        # Join all fragments to get the full deobfuscated code
        deobfuscated_code = ''.join(code_fragments)

        # Generate an output file name based on the input file name
        output_file = input_file.replace(".txt", "_deobfuscated.txt")

        # Write the deobfuscated code to the output file
        with open(output_file, 'w') as f_out:
            f_out.write(deobfuscated_code)

        print(f"Deobfuscated code has been saved to: {output_file}")

    except Exception as e:
        print(f"An error occurred: {e}")

# Main execution: checks if the script is called with the correct argument
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python deobfuscate.py <input_filename>")
    else:
        deobfuscate(sys.argv[1])
