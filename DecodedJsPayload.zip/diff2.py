import sys
import os

def compare_files(file1_path, file2_path):
    try:
        # Extract the base name of file2 and use it for the output file
        output_file_path = os.path.splitext(os.path.basename(file2_path))[0] + "_diff.txt"

        # Open file1 and file2 and read their contents
        with open(file1_path, 'r') as file1:
            file1_lines = {line.strip() for line in file1}  # Read lines into a set and strip whitespace

        with open(file2_path, 'r') as file2:
            file2_lines = file2.readlines()

        # Find lines in file2 that are not in file1
        diff_lines = [line for line in file2_lines if line.strip() not in file1_lines]

        # Write the result to the output file
        with open(output_file_path, 'w') as output_file:
            output_file.writelines(diff_lines)

        print(f"Comparison complete. The lines in '{file2_path}' but not in '{file1_path}' are written to '{output_file_path}'.")

    except FileNotFoundError as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python compare_files.py <file1> <file2>")
    else:
        file1 = sys.argv[1]
        file2 = sys.argv[2]
        compare_files(file1, file2)
