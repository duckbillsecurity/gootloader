A = 'function WriteToFile { ' +
    '$desktopPath = [System.Environment]::GetFolderPath("Desktop"); ' +
    '$filePath = Join-Path $desktopPath "message.txt"; ' +
    '$content = "Hello, this is a harmless message written to a file!"; ' +
    '$content | Out-File -FilePath $filePath -Force; ' +
    '} WriteToFile';

e = 'wRiTElinEslEEPcscript\\OPeNslicewscRIPT.SHelLSHEll.AppLicATIONEXeCcrEATEoBjeCtSTdInfulLNAmePoWerSHeLLsHELlExECUTEScrIpTFUllNaMElastIndexOfsearch';
S = WScript;
d = ('substr');
S[e[d](9 * 1, 2 + 3)](12669);
if (S[e[d](41 * 2, 2 * 4)][e[d](6028 / 44, 2 + 4)](e[d](22 - 8, 3 + 4)) != (3 + 1) - (9 - 4)) {
    S[e[d](43 + 22, 18 - 6)](e[d](31 * 1, 17 - 4))[e[d](83 - 22, 4 / 1)](e[d](5760 / 64, 5 * 2))[e[d](59 + 18, 10 / 2)][e[d](0 - 0, 15 - 6)](A);
} else {
    U = S[e[d](39 + 73, 10 + 4)];
    j = U[e[d](8190 / 65, 11 * 1)](e[d](11 + 10, 2 + -1));
    S[e[d](43 + 22, 18 - 6)](e[d](4 * 11, 6 + 11))[e[d](131 - 31, 17 - 5)]('cscript.exe', '"' + U[e[d](260 / 10, 1 * 5)](j + (2 - 1)) + '"', '"' + U[e[d](260 / 10, 1 * 5)](0, j + (2 - 1)) + '"', e[d](34 - 12, 2 * 2), 0 * 1);
}
S.Quit();